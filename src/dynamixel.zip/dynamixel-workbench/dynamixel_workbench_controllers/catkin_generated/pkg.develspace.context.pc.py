# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/robot/catkin_ws/src/dynamixel-workbench/dynamixel_workbench_controllers/include;/usr/include/eigen3".split(';') if "/home/robot/catkin_ws/src/dynamixel-workbench/dynamixel_workbench_controllers/include;/usr/include/eigen3" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;sensor_msgs;geometry_msgs;dynamixel_workbench_msgs;trajectory_msgs;dynamixel_workbench_toolbox;cmake_modules".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "dynamixel_workbench_controllers"
PROJECT_SPACE_DIR = "/home/robot/catkin_ws/devel"
PROJECT_VERSION = "2.0.0"
