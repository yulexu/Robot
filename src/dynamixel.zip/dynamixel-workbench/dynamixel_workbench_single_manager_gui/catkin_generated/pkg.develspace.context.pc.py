# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/robot/catkin_ws/src/dynamixel-workbench/dynamixel_workbench_single_manager_gui/include".split(';') if "/home/robot/catkin_ws/src/dynamixel-workbench/dynamixel_workbench_single_manager_gui/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;dynamixel_workbench_msgs;dynamixel_workbench_toolbox".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "dynamixel_workbench_single_manager_gui"
PROJECT_SPACE_DIR = "/home/robot/catkin_ws/devel"
PROJECT_VERSION = "2.0.0"
