# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "${prefix}/include".split(';') if "${prefix}/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;dynamixel_sdk".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-ldynamixel_workbench_toolbox".split(';') if "-ldynamixel_workbench_toolbox" != "" else []
PROJECT_NAME = "dynamixel_workbench_toolbox"
PROJECT_SPACE_DIR = "/home/robot/catkin_ws/install"
PROJECT_VERSION = "2.0.0"
